<?php

$connect = mysql_pconnect('localhost', 'botfbnea_bot', '!e.^.%O_q-N]') or die('Cannot connect to Database');
mysql_select_db('botfbnea_bot', $connect) or die('DB_NAME not exists');
mysql_query("SET NAMES 'utf-8'", $connect);
$table =  'bot';
?>