<?php
$com =
array(
'cPhoto' => array(
  '<nama> Ảnh Đẹp À Nha! 😁 ',
       'Đẹppppppp  😚 ',
'Chài ơi chài! <nama> post cái ảnh ngàn năm có 1  👏 ',
'HOTTTT! <nama> đăng ảnh HOTTT thế  💟 ',
),
'cBiasa' => array(
     'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng.
Chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
      ),
'cKondisi' => array(
       array(
           array(
           'jancok',
           ' asu ',
           'anjing',
            'bangsat',
            'brengsek',
            'kontol',
            'jembut',
            ' peli ',
            'turuk',
            'tempik',
            'ngentot',
            'memek',
            'raimu',
            'matamu',
            'celeng',
            'damput',
            'pejuh',
            'jamput',
          ),
      array('Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng.
Chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
             ),
        ),
   array(
      array(
         'http://',
         'https://',
         'www',
           ),
      array(
          'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng.
Chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
            ),
        ),
   array(
      array(
        'telepon',
        'tilpun',
         'tlp',
        'sms',
        'smz',
         'cmz',
           ),
      array('Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
             ),
        ),
   array(
      array(
         'capek',
         'cape',
         'kesel',
         'keju',
         'linu',
         'remok',
           ),
      array(
          'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
             ),
        ),
   array(
      array(
         'galau',
         'gaslo',
         'gazlu',
         'gaslau',
         'galo',
           ),
      array(
          'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
           ),
        ),
   array(
      array(
         'sedih',
         'suedih',
         'duka',
         'merana',
           ),
      array(
          'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
             ),
        ),
   array(
      array(
         'cinta',
         'love',
         'tresno',
           ),
      array('Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
             ),
        ),
   array(
      array(
         'moga',
         'amin',
         'allah',
         'doa ',
             ),
      array(
        'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
             ),
        ),
   array(
      array(
         'hosting',
         'cron jobs',
         'cpanel',
         'whm',
           ),
      array(
         'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
             ),
        ),
   array(
      array(
         'chặn',
         
           ),
      array(
         'Chặn nào nó cũng mở mà. tặng bạn 1 (y) an ủi nè :D <n><telat>',
             ),
        ),
   array(
      array(
            ':D',
                      ),
      array(
            'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
          ),
       ),
    array(
      array(
            'sao',
            'đâu',
            'ai',
          ),
      array(
            'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
            ),
           ),
    array(
      array(
            'jempol',
            'komen',
          ),
      array(
            'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
            ),
           ),
    array(
      array(
            'Chào Tất Cả',
            'hi all',
            'hay all',
          ),
      array(
            'hay juga',
            ),
           ),
    array(
      array(
            'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
                      ),
      array(
           'Tô canh lạnh lẽo nước trong veo.
Vài lát hành tây bé tẻo teo.
Nước chấm gọi là hơi gợn tí.
Thịt kho thái mỏng gió bay vèo.
Dưa vừa mới muối còn xanh ngắt.
Cơm chén vừa xong dạ vẫn teo.
Tối đói cồn cào không ngủ được.
Muỗi bu vào đốt cái thân bèo.<n><telat>
',
'Lên non mới biết non cao.
Có bồ mới biết vì sao hết tiền.<n><telat>
',
'Khi xưa vác bút theo thầy.
Bây giờ em lại vác cày theo trâu.<n><telat>
',
'Dạy con từ thuở còn thơ.
Dạy vợ từ thuở nó chưa dạy mình.<n><telat>
',
'Không cần ai hiểu, chẳng cần ai tin
Chỉ thích một mình, lạnh lùng, lặng lẽ
Không cần chia sẻ, chẳng cần quan tâm
Chỉ muốn lặng thầm, bình yên là đủ.<n><telat>
',
'Trai có bồ như hoa có chậu
Em nào thâm hậu
Đập chậu cướp hoa.<n><telat>
',
'Yêu nhau sợ núi, sợ đèo
Sợ sông, sợ biển, sợ nghèo, sợ con
Còn trời, còn nước, còn non
Còn cây ăn trái, anh còn sợ em...<n><telat>
',
                    ),
           ),
    array(
      array(
            'lạ',
          ),
      array(
            'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
            ),
       ),
    array(
      array(
            'wkwk',
            'haha',
            'hihi',
            'xixi',
            'hehe',
          ),
      array(
            'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
            ),
       ),
    array(
      array(
            'bot',
            'auto',
            'hack'
          ),
      array(
            'Bot Like Tại K-BotFb .Net Nhận Dạng Rất Là Chuẩn Nha<n><telat>',
            ),
       ),
    array(
      array(
            'tt',
            'báo',
'done',
'hóng',
'dsv',
          ),
      array(
           'Done! nha <nama> ...!!! <telat>',
            ),
       ),
    array(
      array(
            'Vũ Nguyễn Khánh',            
          ),
      array(
           'Chài ơi chài! Vũ Nguyễn Khánh làm ra K-BotFb .Net đó má :v <telat>',
            ),
       ),
    array(
      array(
            'f.s',
            'f/s',
          ),
      array(
            'Cho 1 tấm Fs nhé! <nama> <telat>',
            ),
       ),
    array(
      array(
            'vì',
            'ngu',
            'một',
          ),
      array(
            'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
            ),
       ),
    array(
      array(
            'trims',
            'rimakasih',
            'thanks',
          ),
      array(
            'Áo anh sứt chỉ đường tà. 
Vứt làm nùi giẻ lau nhà cho xong.<n><telat>
',
'Ta về ta tắm ao ta.
Dù trong dù đục cũng là cái ao.<n><telat>
',
'Chồng người áo gấm xông hương. Chồng em áo rách, em thương... chồng người.<n><telat>
',
'Làm sao kiếm được nhiều tiền ? 
Làm sao kiếm được tên miền thật ngon ? 
Làm sao giấc ngủ cho tròn ? 
Làm sao khi chết vẫn còn lưu danh ? 
Làm sao để tiền bóng banh ? 
Làm sao để nó nhanh nhanh sinh lời ? 
Làm sao sống giữa cuộc đời ? 
Làm sao sống được chơi bời xa hoa ? 
Làm sao cứ mãi trêu hoa ? 
Làm sao biết được người ta yêu mình? 
Làm sao biết cách tỏ tình ? 
Làm sao biết được rằng mình đang yêu ? <n><telat>
',
'Yêm em mấy núi cũng trèo
Khi em mang bụng mấy đèo anh cũng dông!!!<n><telat>
',
'Chán đời cắt tóc đi tu 
Nghĩ đi nghĩ nghĩ lại ... đi tù sướng hơn 
Trong tù làm chủ giang sơn 
Một căn phòng đá với dăm ba thằng 
Thằng nào cũng có khiếu năng 
Thằng thì giỏi hóạ thằng thì làm thơ 
Có thằng lại đứng ngẩn ngơ
Vì sao ta lại trở vô nhà tù<n><telat>
',
'Cổng trường đại học cao vời vợi 
Đồng ruộng mênh mông đón em về<n><telat>
',
            ),
       ),
   ),

'cNo1' => array(
        'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
        ),

'cNoZ' => array(
       'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
       ),

'cLatah1'=> array(
      'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
       ),

'cLatah'=> array(
      'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
   ),

'cKata' => array(
      'Vì tương lai con em chúng ta. Đánh chết cha con em chúng nó!!!  🐮 <n><telat>
',
'Không nói chuyện trong khi hôn. 🐥<n><telat>
',
'Học hành như cá kho tiêu, kho nhiều thì mặn học nhiều thì ngu. 🐙<n><telat>
',
'Tiên học lễ hậu học....ăn. <n><telat>
',
'Thiếu nữ là chữ viết tắt của....thiếu nữ tính. 💢<n><telat>
',
'Còn....nói còn tát. 🎤<n><telat>
',
'Một điều nhịn là chín điều nhục. 〽<n><telat>
',
'Cá không ăn muối cá ươn. Con không ăn muối....thiếu iot rồi con ơi. <n><telat>
',
'Hãy cho tôi một điểm tựa, tôi....mỏi lắm rồi. 🔰<n><telat>
',
'Chúng ta yêu súc vật, vì....thịt chúng rất ngon. 🔰<n><telat>
',
'Người yêu không tự sinh ra và cũng không tự mất đi, mà nó chỉ chuyển từ tay thằng này sang tay thằng khác!!! <n><telat>
',
'Dụng binh không gì quý bằng thần tốc, Dụng đàn bà không gì quý bằng tâng bốc. <n><telat>
',
'Đằng sau người đàn ông thành công luôn luôn có một người phụ nữ..........nói rằng anh ta sẽ chẳng bao giờ làm được điều gì nên hồn cả.!! <n><telat> ',
'Ăn chọn nơi, chơi chọn hàng, lang thang chọn địa điểm. <n><telat>
',
'Những cái hôn vụng trộm bao giờ cũng ngọt ngào nhất và bao giờ cũng tiềm ẩn những cái tát nảy đom đóm mắt nhất. <n><telat>
',
'Để yêu một người đã khó, để đá nó càng khó hơn. <n><telat>
',
'Đá bồ là một nghệ thuật và người đá bồ cũng là một nghệ sĩ. <n><telat>
',
'Tình bạn sau tình yêu là phát đạn ân huệ cuả kẻ tử tù.  👸<n><telat>
',
'Đèn nhà ai nấy rạng, vợ thằng bạn thì cố mà chăm.<n><telat>  ',
' Da thịt đàn bà được nuôi dưỡng bằng âu yếm, lòng dạ đàn bà được nuôi dưỡng bằng kinh phí. <n><telat>
',
'Trên bước đường thành công không có dấu chân của kẻ lười biếng vì kẻ lười biếng thì có đi bộ bao giờ, nhìn kỹ thì sẽ thấy rất nhiều vết bánh xe của họ để lại.<n><telat> 
',
'Tiền không thành vấn đề, 🐔 vấn đề là không có tiền. <n><telat>
',
'Trăm năm kiều vẫn là kiều. Nên lần đầu khó là điều tất nhiên.  🔔<n><telat>
',
'Bạn đừng đi tìm người hoàn thiện, vì không có ai hoàn thiện cả. Chỉ khi bạn yêu họ, họ mới hoàn thiện. <n><telat>
',
'Hoa mọc trên tuyết vẫn tươi, người trong đau khổ vẫn cười là anh. <n><telat>
',
'Dù ai nói ngả nói nghiêng, chàng lười vẫn cứ triền miên chép bài. <n><telat>
',
' Yêu nhau trái ấu cũng tròn, ghét nhau đôi dép dẫu mòn cũng chia. <n><telat>
',
'Kiếp sau xin chớ làm người, nguyện làm gia xúc cho nàng hốt phân. <n><telat>
',
' Lời nói chẳng mất tiền mua, lựa lời mà nói cho đừng đập nhau. 🍳<n><telat>
',
'Đàn ông miệng rộng thì sang, đàn bà miệng rộng tan hoang cửa nhà. 💝<n><telat>
',
'Học mà không chơi đánh rơi tuổi trẻ, Chơi mà không học bán rẻ tương lai. Thôi thì ta chọn cả hai, Vừa chơi vừa học tương lai huy hoàng. <n><telat>
',
'Gà mà không gáy là con gà chiên.
Gà mà hay gáy là con gà điên.
Đi lang thang trong sân ,bắt con gà, bỏ vô nồi.
Mua 2 lon Tiger , nhắm chân gà , nhắm chân gà.
Gà mà không gáy là con gà gay.
Gà mà không gáy là con gà toi.
Đi lang thang trong sân, bắt con gà, ướp tiêu hành.
Ăn lăn quay ra, chết tui rùi, cúm gia cầm<n><telat>
',
'Ba là con cá mập, mẹ là con cá voi, con là con cá kình, ba con cá hung hăng, la là lá la la ... quốc hết 1 con bò.
Ba là xúc xích bò, Mẹ là xúc xích heo, Con là xúc xích gà, 3 xúc xích ngon ngon, la là lá la la ... Nấu với mì ăn liền.
Ba là tên cướp vàng, Mẹ là tên cướp đô, Con là tên cướp tiền, 3 tên cướp lưu manh, la là lá la la ... Cướp hết 1 ngân hàng.
Lung lay lung lay tình Mẹ, tình Cha, Lung lay lung lay tội một mái nhà. Lung lay lung lay tình Mẹ tình cha, Lung lay lung lay hai tiếng...ra toà. He he !<n><telat>
',
'Mồng 8/3 em ra ngoài đồng,
chọn một bông hoa như con heo tặng bạn gái.
Nào bông nào ọe ,nào bông nào bông ghê.
1 phút 3 giây, bạn đã bay lên trời<n><telat>
',
'Làm thơ mình vốn không quen
Nhưng vì...muốn quá nên xen một bài
Bài này không được quá dài
Cũng không được ngắn kẻo hoài phí công
Làm thơ phải có...màu hồng ⛺
Có mây,có gió bềnh bồng lướt bay ⛔
Làm thơ phải có mê say
Đã làm là suốt đêm ngày không thôi
Không nên chỉ biết viết,ngồi 💟
Phải ra ngắm cảnh,nhìn trời...lấy thơ
Khi nào đầu óc lơ mơ
Học bài thì khó,làm thơ rất vào
Mỗi khi cảm xúc tuôn trào 😏
Chính là đất nặn để nhào ra thơ
Khi nào đầu óc lơ mơ
Nói gì thế nhỉ?Ơ ơ...hết rồi
Chú ý quan trọng : Đây không phải là bí kíp thật.Bạn nào làm theo là thành thơ...dở hơi ăn canh mồng tơi đó!HÌ HÌ<n><telat>
',
'Lấy vợ nên kiêng lấy vợ non
Ra đường ai biết cháu hay con
Nhí nha nhí nhảnh đòi vàng bạc
Bán cả bàn thờ sắm phấn son!<n><telat>
',
'Lấy vợ ta nên lấy vợ non
Tóc thề mườn mượt xõa eo thon
Mắt sáng, môi hồng, da tươi thắm
Đỡ tiền mua sắm những phấn son!<n><telat>
',
'Lấy vợ nên kiêng lấy vợ già
Ra đường ai biết chị hay bà
Sinh hai ba lượt mình teo nhếch
Má hóp, xương lòi, ốm như ma!<n><telat>
',
'Lấy vợ xin anh lấy vợ già
Ra đường em biết chuyện gần xa
Lỡ anh đi lạc thì em nhắc
Cũng tốt cho anh đó thôi mà!<n><telat>
',
'Lấy vợ nên kiêng vợ ngáy to
Đêm nào đi ngủ cũng khò khò
Tội đức lang quân nằm kế cạnh
Mất ngủ lâu ngày chắc phát ho!<n><telat>
',
     ),
   'cAcak' => $text,
   );

 function _req($url,$type=null){
   $opts = array(
            19913 => 1,
            10002 => $url,
            10018 => 'MAUI-based Generic / bOt Koplak by Danz Ze',
            );
   $ch=curl_init();
   curl_setopt_array($ch,$opts);
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
  }

 function saveFile($x,$y){
   $f = fopen($x,'w');
             fwrite($f,$y);
             fclose($f);
   }

 function getData($dir,$token,$params=null){
    $param = array(
        'access_token' => $token,
        );
   if($params){ 
       $arrayParams=array_merge($params,$param);
       }else{
       $arrayParams =$param;
       }
   $url = getUrl('graph',$dir,$arrayParams);
   $result = json_decode(_req($url),true);
   if($result[data]){
       return $result[data];
       }else{
       return $result;
       }
   }

 function getUrl($domain,$dir,$uri=null){
   if($uri){
       foreach($uri as $key =>$value){
           $parsing[] = $key . '=' . $value;
           }
       $parse = '?' . implode('&',$parsing);
       }
   return 'https://' . $domain . '.facebook.com/' . $dir . $parse; 
   }

function getLog($x,$y){
if(!is_dir('log')){
   mkdir('log');
   }
   if(file_exists('log/cm2_'.$x)){
       $log=file_get_contents('log/cm2_'.$x);
       }else{
       $log=' ';
       }

  if(ereg($y[id],$log)){
       return false;
       }else{
if(strlen($log) > 2000){
   $n = strlen($log) - 2000;
   }else{
  $n= 0;
   }
       saveFile('log/cm2_'.$x,substr($log,$n).' '.$y[id]);
       return true;
      }
 }

 function getC($c,$me,$data,$n,$emo){

       foreach($c[cKondisi] as $txt){
           foreach($txt[0] as $kata){
               if(ereg($kata,strtolower($data[$n][message]))){
                   $tKondisi = $txt[1];
                   $kondisi=true;
                   }
               }
           }

    $type=acak();

if($data[$n][type] == 'photo'){ $text = $c[cPhoto]; }
elseif($kondisi){ $text = $tKondisi; }
elseif($type == 'cNomer'){ 
if(count($data[$n][comments][data]) == 0 ){ $text = $c[cNo1]; }else{  $text = $c[cNoZ]; }
         }
elseif($type == 'cLatah'){ 
        if($n == 0 || $n == count($data)-1){ $text = $c[cLatah1]; }else{ $text = $c[cLatah]; }
         }
elseif($type == 'cKata'){ $text = $c[cAcak]; }
elseif($type == 'cBiasa'){ $text = $c[cBiasa]; }

  $replace = array(
        '<ucapan>',
        '<me>',
        '<nama>',
        '<idA>',
        '<idZ>',
        '<posA>',
        '<posZ>',
        '<mess>',
        '<messA>',
        '<messZ>',
        '<comA>',
        '<comZ>',
        '<no>',
        '<n>',
        '<lucu>',
        '<konyol>',
        '<motivasi>',
        '<telat>',
     ); 
  $p= urldecode('%0A') . '::::::::::::::::::::::::::::::::::::::::: (y) :::::::::::::::::::::::::::::::::::::::::' . urldecode('%0A');

  $replaced = array(
     ucapan(),
     ' @['.$me.':1] ',
     getName($data[$n][from][id],$data[$n][from][name]),
     getName($data[$n-1][from][id],$data[$n-1][from][id]),
     getName($data[$n+1][from][id],$data[$n+1][from][id]),
     getName($data[$n][comments][data][0][from][id],$data[$n][comments][data][0][from][name]),
     getName($data[$n][comments][data][count($data[$n][comments][data])-1][from][id],$data[$n][comments][data][count($data[$n][comments][data])-1][from][name]),
     $p.$data[$n][message].$p,
     $p.$data[$n-1][message].$p,
     $p.$data[$n+1][message].$p,
     $p.$com[0][message].$p,
     $p.$data[$n][comments][data][count($data[$n][comments][data])-1][message].$p,
     count($data[$n][comments][data])+1,
     urldecode('%0A'),
     $p.$asem.$p,
     $p.$asem.$p,
     $p.$asem.$p,
     getDelay($data[$n][created_time],1),
    );
   $result=str_replace($replace,$replaced,$text[rand(0,count($text)-1)]);
if($emo==1){
return getEmo($result);
}else{
return $result;
}
}
function getEmo($n){

$emo=array(
urldecode('%F3%BE%80%80'),
urldecode('%F3%BE%80%81'),
urldecode('%F3%BE%80%82'),
urldecode('%F3%BE%80%83'),
urldecode('%F3%BE%80%84'),
urldecode('%F3%BE%80%85'),
urldecode('%F3%BE%80%87'), 
urldecode('%F3%BE%80%B8'), 
urldecode('%F3%BE%80%BC'),
urldecode('%F3%BE%80%BD'),
urldecode('%F3%BE%80%BE'),
urldecode('%F3%BE%80%BF'),
urldecode('%F3%BE%81%80'),
urldecode('%F3%BE%81%81'),
urldecode('%F3%BE%81%82'),
urldecode('%F3%BE%81%83'),
urldecode('%F3%BE%81%85'),
urldecode('%F3%BE%81%86'),
urldecode('%F3%BE%81%87'),
urldecode('%F3%BE%81%88'),
urldecode('%F3%BE%81%89'), 
urldecode('%F3%BE%81%91'),
urldecode('%F3%BE%81%92'),
urldecode('%F3%BE%81%93'), 
urldecode('%F3%BE%86%90'),
urldecode('%F3%BE%86%91'),
urldecode('%F3%BE%86%92'),
urldecode('%F3%BE%86%93'),
urldecode('%F3%BE%86%94'),
urldecode('%F3%BE%86%96'),
urldecode('%F3%BE%86%9B'),
urldecode('%F3%BE%86%9C'),
urldecode('%F3%BE%86%9D'),
urldecode('%F3%BE%86%9E'),
urldecode('%F3%BE%86%A0'),
urldecode('%F3%BE%86%A1'),
urldecode('%F3%BE%86%A2'),
urldecode('%F3%BE%86%A4'),
urldecode('%F3%BE%86%A5'),
urldecode('%F3%BE%86%A6'),
urldecode('%F3%BE%86%A7'),
urldecode('%F3%BE%86%A8'),
urldecode('%F3%BE%86%A9'),
urldecode('%F3%BE%86%AA'),
urldecode('%F3%BE%86%AB'),
urldecode('%F3%BE%86%AE'),
urldecode('%F3%BE%86%AF'),
urldecode('%F3%BE%86%B0'),
urldecode('%F3%BE%86%B1'),
urldecode('%F3%BE%86%B2'),
urldecode('%F3%BE%86%B3'), 
urldecode('%F3%BE%86%B5'),
urldecode('%F3%BE%86%B6'),
urldecode('%F3%BE%86%B7'),
urldecode('%F3%BE%86%B8'),
urldecode('%F3%BE%86%BB'),
urldecode('%F3%BE%86%BC'),
urldecode('%F3%BE%86%BD'),
urldecode('%F3%BE%86%BE'),
urldecode('%F3%BE%86%BF'),
urldecode('%F3%BE%87%80'),
urldecode('%F3%BE%87%81'),
urldecode('%F3%BE%87%82'),
urldecode('%F3%BE%87%83'),
urldecode('%F3%BE%87%84'),
urldecode('%F3%BE%87%85'),
urldecode('%F3%BE%87%86'),
urldecode('%F3%BE%87%87'), 
urldecode('%F3%BE%87%88'),
urldecode('%F3%BE%87%89'),
urldecode('%F3%BE%87%8A'),
urldecode('%F3%BE%87%8B'),
urldecode('%F3%BE%87%8C'),
urldecode('%F3%BE%87%8D'),
urldecode('%F3%BE%87%8E'),
urldecode('%F3%BE%87%8F'),
urldecode('%F3%BE%87%90'),
urldecode('%F3%BE%87%91'),
urldecode('%F3%BE%87%92'),
urldecode('%F3%BE%87%93'),
urldecode('%F3%BE%87%94'),
urldecode('%F3%BE%87%95'),
urldecode('%F3%BE%87%96'),
urldecode('%F3%BE%87%97'),
urldecode('%F3%BE%87%98'),
urldecode('%F3%BE%87%99'),
urldecode('%F3%BE%87%9B'), 
urldecode('%F3%BE%8C%AC'),
urldecode('%F3%BE%8C%AD'),
urldecode('%F3%BE%8C%AE'),
urldecode('%F3%BE%8C%AF'),
urldecode('%F3%BE%8C%B0'),
urldecode('%F3%BE%8C%B2'),
urldecode('%F3%BE%8C%B3'),
urldecode('%F3%BE%8C%B4'),
urldecode('%F3%BE%8C%B6'),
urldecode('%F3%BE%8C%B8'),
urldecode('%F3%BE%8C%B9'),
urldecode('%F3%BE%8C%BA'),
urldecode('%F3%BE%8C%BB'),
urldecode('%F3%BE%8C%BC'),
urldecode('%F3%BE%8C%BD'),
urldecode('%F3%BE%8C%BE'),
urldecode('%F3%BE%8C%BF'), 
urldecode('%F3%BE%8C%A0'),
urldecode('%F3%BE%8C%A1'),
urldecode('%F3%BE%8C%A2'),
urldecode('%F3%BE%8C%A3'),
urldecode('%F3%BE%8C%A4'),
urldecode('%F3%BE%8C%A5'),
urldecode('%F3%BE%8C%A6'),
urldecode('%F3%BE%8C%A7'),
urldecode('%F3%BE%8C%A8'),
urldecode('%F3%BE%8C%A9'),
urldecode('%F3%BE%8C%AA'),
urldecode('%F3%BE%8C%AB'), 
urldecode('%F3%BE%8D%80'),
urldecode('%F3%BE%8D%81'),
urldecode('%F3%BE%8D%82'),
urldecode('%F3%BE%8D%83'),
urldecode('%F3%BE%8D%84'),
urldecode('%F3%BE%8D%85'),
urldecode('%F3%BE%8D%86'),
urldecode('%F3%BE%8D%87'),
urldecode('%F3%BE%8D%88'),
urldecode('%F3%BE%8D%89'),
urldecode('%F3%BE%8D%8A'),
urldecode('%F3%BE%8D%8B'),
urldecode('%F3%BE%8D%8C'),
urldecode('%F3%BE%8D%8D'),
urldecode('%F3%BE%8D%8F'),
urldecode('%F3%BE%8D%90'),
urldecode('%F3%BE%8D%97'),
urldecode('%F3%BE%8D%98'),
urldecode('%F3%BE%8D%99'),
urldecode('%F3%BE%8D%9B'),
urldecode('%F3%BE%8D%9C'),
urldecode('%F3%BE%8D%9E'), 
urldecode('%F3%BE%93%B2'), 
urldecode('%F3%BE%93%B4'),
urldecode('%F3%BE%93%B6'), 
urldecode('%F3%BE%94%90'),
urldecode('%F3%BE%94%92'),
urldecode('%F3%BE%94%93'),
urldecode('%F3%BE%94%96'),
urldecode('%F3%BE%94%97'),
urldecode('%F3%BE%94%98'),
urldecode('%F3%BE%94%99'),
urldecode('%F3%BE%94%9A'),
urldecode('%F3%BE%94%9C'),
urldecode('%F3%BE%94%9E'),
urldecode('%F3%BE%94%9F'),
urldecode('%F3%BE%94%A4'),
urldecode('%F3%BE%94%A5'),
urldecode('%F3%BE%94%A6'),
urldecode('%F3%BE%94%A8'), 
urldecode('%F3%BE%94%B8'),
urldecode('%F3%BE%94%BC'),
urldecode('%F3%BE%94%BD'), 
urldecode('%F3%BE%9F%9C'), 
urldecode('%F3%BE%A0%93'),
urldecode('%F3%BE%A0%94'),
urldecode('%F3%BE%A0%9A'),
urldecode('%F3%BE%A0%9C'),
urldecode('%F3%BE%A0%9D'),
urldecode('%F3%BE%A0%9E'),
urldecode('%F3%BE%A0%A3'), 
urldecode('%F3%BE%A0%A7'),
urldecode('%F3%BE%A0%A8'),
urldecode('%F3%BE%A0%A9'), 
urldecode('%F3%BE%A5%A0'), 
urldecode('%F3%BE%A6%81'),
urldecode('%F3%BE%A6%82'),
urldecode('%F3%BE%A6%83'), 
urldecode('%F3%BE%AC%8C'),
urldecode('%F3%BE%AC%8D'),
urldecode('%F3%BE%AC%8E'),
urldecode('%F3%BE%AC%8F'),
urldecode('%F3%BE%AC%90'),
urldecode('%F3%BE%AC%91'),
urldecode('%F3%BE%AC%92'),
urldecode('%F3%BE%AC%93'),
urldecode('%F3%BE%AC%94'),
urldecode('%F3%BE%AC%95'),
urldecode('%F3%BE%AC%96'),
urldecode('%F3%BE%AC%97'),
);
$mess=$emo[rand(0,count($emo)-1)];
$message = explode(' ',$n);
foreach($message as $x => $y){
$mess .= $emo[rand(0,count($emo)-1)].' '.$y.' ';
}
return($mess);
}


function banner(){
$bot[jam] = 13;
   $time=date('Y',time()+($bot[jam]*3600));
   $set=(($time-1)*365)+(int)(($time-1)/4)+(date('z',time()+($bot[jam]*3600)));
   $dino=$set-(7*(int)($set/7));
   $pasar=$set-(5*(int)($set/5));
   $hari=array('BOT','LIKE','Tương','Tác','Cực','Chất',);
   $pasaran = array(' ','Khánh',' ',);
   $no=array(6,0,1,2,3,4,5,);
   $result = '@@[0:[0:1:O===========OO===========O]]
'.str_replace($no,$hari,$dino).' :v '.str_replace($no,$pasaran,$pasar).'  || '.date('d F Y',time()+($bot[jam]*3600)).' ||  '.date('H:i',time()+($bot[jam]*3600)).' Wib 
[[100006207068575]] http://m.facebook.com/100006207068575
➡ BOTLIKE. TOP ⬅ 
';
return $result;
}

function getName($id,$name){
if(ereg(' ',$name)){$n=explode(' ',$name); $x=$n[0];}else{$x=$name;}
return ' @['.$id.':'.$x.'] ';
}

function acak(){
    $acak = array('cBiasa','cNomer','cLatah','cKata',);
    return($acak[rand(0,count($acak)-1)]);
    }

function getDelay($n,$x=null){
$texts =array(
                    '💟===========💟💟===========💟
               ✌ Bot Like & Bot Cmt Tại ➡ BOTLIKE. TOP ⬅ 
                    😊 Admin : Trần Hữu Nhi 😊
                     ♥===========♥♥===========♥  
                 https://www.facebook.com/profile.php ',
                                                           );
  if(!$x){ $text=$texts[rand(0,count($texts)-1)];}
  $n=substr($n,11,8);
  $l=explode(':',$n);
  $t=((gmdate('i')*60)+gmdate('s'))-(($l[1]*60)+$l[2]);
  $m=floor($t/60);
  $d=$t-($m*60);
if($d<0){ return false;}else{
  if($m==0){
       return $text.'   💟  💞  ♥  💞  💟 ';
       }else{
       return $text.'   👌  👏  🙌  💪  ✊  ✌  ☝ ';
       }
   } 
}

 function ucapan(){
$bot[jam]=7;
   $jam = array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
   $sapa = array(':3 Like Rồi Nha!');
   $time = gmdate('H',time()+$bot[jam]*3600);
   return str_replace($jam,$sapa,$time);
   }

function isMy($post,$me){
  if($post[from][id] == $me){
     return true;
     }else{
     return false;
    }
}

function komen($c,$me,$token,$telat,$banner,$emo){
$stat = getData('me/home',$token,array(
      'fields' => 'id,message,from,type,created_time,comments.id,comments.message,comments.from,comments.limit(100)',
      'limit' => 10,
                     )
                );

for($i=0;$i<count($stat);$i++){
if($stat[$i]){
       if(getLog($me,$stat[$i]) && !isMy($stat[$i],$me)){
          $message=getC($c,$me,$stat,$i,$emo);
          if($banner == '1'){
               $message .= urldecode('%0A') .  banner();
                }
          if($telat == '1'){
                $message .=urldecode('%0A') . getDelay($stat[$i][created_time]);
                 }
          getData($stat[$i][id].'/comments',$token,array(
                      'message' => urlencode($message),
                     'method'=> 'post',
                      )
                 );
          }
     }
  } 
}
$open=opendir('../HANG00_TOKEN/cmT2');
while($file=readdir($open)){
if($file != '.' && $file != '..'){
$con[]=explode('_',$file);
}
}
closedir($open);
for($i=0;$i<count($con);$i++){
komen($com,$con[$i][0],$con[$i][1],$con[$i][2],$con[$i][3],$con[$i][4]);
}
?>