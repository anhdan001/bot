<?php
$host = "68.65.120.211:3306";
$username = "oppanhan_nhidz";
$password = "nhidz123";	
$dbname = "oppanhan_nhidz";
$connection = mysql_connect($host,$username,$password);
if (!$connection){
die('Could not connect: ' . mysql_error());
}
mysql_select_db($dbname) or die(mysql_error());
mysql_query("SET NAMES utf8");
?>