<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>
K-BotFb .Net - Bot Like Facebook - HoaDZ.ORG
</title>
<meta name="description" content="Bot Like + Bot Cmt + Interactive Bot + Bot Inbox Facebook" />
<body>
<center>
<h1>Vào Đây Làm Làm Gì Thế -_- </h1>
<h2> Quay Trở Lại <a href="../index.php">Trang Chủ</a> Nào !!!</h2>
</center>
</body>
</head>
</html>