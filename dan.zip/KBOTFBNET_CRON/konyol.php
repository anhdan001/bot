<?php
$text = array("<3 <telat>",);
?>