<?php
$text = array("<3 <3 <telat>",);
?>