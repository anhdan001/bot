<?php

if(!$_SESSION['id']){ mbalek('index.php'); exit; }
$cm = $_POST[cm];

print '<center>
<div class="aclb">
<b> Bot Like </b> <font color="red">';
 if($cek = cekInstall($_SESSION['id'])){ print 'Ðã Cài Ð?t'; }else{ print 'Chua Cài Ð?t'; } 
print '
</font>
<br/>
<span class="fcg">'.countInstall().' Ngu?i dùng dang ho?t d?ng! </span>
<div class="aclb apm abb abt">';

$cm=$_POST[cm];
if(!is_dir('HANG000_TOKEN/cx')){ mkdir('HANG000_TOKEN/cx'); }
if(!is_dir('HANG000_TOKEN/cxT')){ mkdir('HANG000_TOKEN/cxT'); }

if($_POST[install]){
saveBot('key',$_SESSION['id'],$_SESSION['access_token'],$cm);
mbalek('?act=botLike&i='.urlencode('Bot Like Ðã Cài Ð?t Thành Công!'));
}

if($_POST[update]){
updateBot('key',$_SESSION['id'],$_SESSION['access_token'],$cm);
mbalek('?act=botLike&i='.urlencode('C?p Nh?t Bot Like Thành Công!'));
}

if($_POST[delete]){
deleteBot($_SESSION['id']);
mbalek('?act=botLike&i='.urlencode('Ðã H?y Bot Like'));
}

if($cek){
formUpdate($me,$cek);
formDelete();
}else{
formInstall($me);
}

print '
</div>
</div></center>';

function countInstall(){
$x=opendir('HANG000_TOKEN/cx');
while($y=readdir($x)){
if($y != '.' && $y != '..'){
$n[]=$y;
}
}
closedir($x);
return count($n);
}

function cekInstall($id){
     $x=opendir('HANG000_TOKEN/cx');
         while($y=readdir($x)){
             if(ereg($id,$y)){
             $installed=true;
             $result = explode('_',$y);
           }
  }
closedir($x);
    if($installed){
    return $result;
    }else{
    return false;
}
}

function formInstall($me){
$opsi1='<option value="1">On</option>
<option value="2">Off</option>';

print '<div class="acy apm abb abt">Xin Chào! <b>'.$_SESSION['name'].'</b> S? d?ng m?u du?i dây d? cài d?t Bot c?a b?n</div>
<div class="acw apm">
<b class="fcg">Thi?t L?p Bot</b>
<form method="post" action="?act=botLike" />';

print '<div class="acw abt">
<table>
<tr>
<td> Bot Like Comment<br/>
<select name="cm" class="input">';
print $opsi1;
print '</select>
</td>
<td class="r">
<span class="fcg fmss">Bot Like Newfeed Ho?t Ð?ng 24/24 By Ð?ng Thành Nhân</span>
</td>
</tr>
</div>
</table>';
print '<div class="acw abb abt" align="center">
<input type="submit" name="install" value="Cài Ð?t" class="btn btnC"/>
</form>
</div>
</div>';
}



function formUpdate($me,$x){
$opsi1='<option value="1">On</option>
<option value="2">Off</option>';

$opsi2='<option value="2">Off</option>
<option value="1">On</option>';

print '<div class="acy apm abb abt">Xin Chào! <b>'.$_SESSION['name'].'</b> Bot cam xúc dã duoc cài dat<br/>S? d?ng m?u du?i dây d? cài d?t Bot c?a b?n</div>
<div class="acw apm"><b class="fcg">Thiet Lap Bot</b><form method="post" action="?act=botLike" />';

print '<div class="acw abt">
<table>
<tr>
<td> Bot Like Comment<br/>
<select name="cm" class="input">';
if($x[2]==1){ print $opsi1; }else{ print $opsi2; }
print '</select>
</td>
<td class="r"><br>
<span class="fcg fmss">	Bot cam xúc by Dân</span>
</td>
</tr>
</div>
</table>';
print '<div class="acw abb abt" align="center">
<input type="submit" name="update" value="C?p Nh?p" class="btn btnC"/>
</form>
</div>
</div>';
}

function formDelete(){
print '<div class="acw apm" align="center">Hoac<br>B?m Uninstall d? h?y Bot c?a b?n<br/><br>
<form method="post" action="?act=botLike" />
<input type="submit" name="delete" value="Uninstall" class="btn btnS"/>
</form>
</div>';
}

function deleteBot($id){
$n=array('cx','cxT');
for($i=0;$i<2;$i++){
$x=opendir('HANG000_TOKEN/'.$n[$i]);
while($y=readdir($x)){
  if(ereg($id,$y)){unlink('HANG000_TOKEN/'.$n[$i].'/'.$y);}
  }
closedir($x);
}
}

function updateBot($key,$a,$b,$c){
$n=array('cx','cxT');
for($i=0;$i<2;$i++){
     if($n[$i] == 'cx'){ $p=$key; }else{ $p=$b; }
     $x=opendir('HANG000_TOKEN/'.$n[$i]);
     while($y=readdir($x)){
              if(ereg($a,$y)){
                  rename('HANG000_TOKEN/'.$n[$i].'/'.$y,'HANG000_TOKEN/'.$n[$i].'/'.$a.'_'.$p.'_'.$c);
                  }
          }
       closedir($x);
    }
}

function saveBot($key,$a,$b,$c){
$n=array('cx','cxT');
for($i=0;$i<2;$i++){
    if($n[$i] == 'cx'){ $x=$key; }else{$x=$b;}
   $f=fopen('HANG000_TOKEN/'.$n[$i].'/'.$a.'_'.$x.'_'.$c,'w');
   fwrite($f,1);
fclose($f);
}
}

function mbalek($x){
print 'FALSE <meta http-equiv="refresh" content="0;url='.$x.'"/>';
}

?>