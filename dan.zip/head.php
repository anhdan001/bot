<?php
session_start();
error_reporting(0);
$act = $_GET['act'];

?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="content-type" content="text/html; UTF-8" />
<meta http-equiv="cache-control" content="cache" />
<meta http-equiv="content-language" content="vi" />
<meta http-equiv="revisit-after" content="1 days" />
<meta name="google-site-verification" content="TJb-NSONmEF4h9h_7RUSZJ1z9ANGrfhkx8d7iJD1eWs" />

<!-- SEO -->
<title>BOTLIKE.TOP | Bot Like | Bot cmt | bot cảm xúc | bom like | bom cmt | bom cảm xúc .</title>

<meta name="description" content="BOTLIKE.TOP Là Một Công Cụ Đắc Lực Giúp Bạn Quản Lí Tài Khoản Facebook Một Cách Tự Động Hóa. Bao Gồm Các Chức Năng Như: Bot Like, Bot Auto Comment, Bot Ex Like, Bom Like, Bom Cmt, Bom Wall, Bot Auto Reply Inbox, Bot Auto Update Stt, Bot Delete Stt, Bot Auto Confirm Friend Request, Bot Auto Poke, Auto Like, Auto Share, Auto Sub Facebook..." />
<meta name="keywords" content="BOTLIKE.TOP, tang like, hack like facebook, buff like, hack like viet nam, trang web hack like facebook, auto like viet nam, buff like viet nam,cách tăng like stt facebook, hack like ảnh facebook, hack like comment facebook, tăng like ảnh facebook, cách hack tăng like,share code auto like, xin code auto like, web auto like" />
<meta name="author" content="Trần Lê Anh Dân" />
<meta name="copyright" content="BOTLIKE.TOP" />
<meta name="robots" content="index, follow" />
<meta property="fb:admins" content="https://www.facebook.com/106DH" />
<meta property="og:url" content="http://BOTLIKE.TOP/" />
<meta property="og:type" content="website" />
<meta property="og:description" content="BOTLIKE.TOP Là Một Công Cụ Đắc Lực Giúp Bạn Quản Lí Tài Khoản Facebook Một Cách Tự Động Hóa. Bao Gồm Các Chức Năng Như: Bot Like, Bot Auto Comment, Bot Ex Like, Bom Like, Bom Cmt, Bom Wall, Bot Auto Reply Inbox, Bot Auto Update Stt, Bot Delete Stt, Bot Auto Confirm Friend Request, Bot Auto Poke, Auto Like, Auto Share, Auto Sub Facebook..." />
<meta property="og:title" content="BOTLIKE.TOP Là Một Công Cụ Đắc Lực Giúp Bạn Quản Lí Tài Khoản Facebook Một Cách Tự Động Hóa. Bao Gồm Các Chức Năng Như: Bot Like, Bot Auto Comment, Bot Ex Like, Bom Like, Bom Cmt, Bom Wall, Bot Auto Reply Inbox, Bot Auto Update Stt, Bot Delete Stt, Bot Auto Confirm Friend Request, Bot Auto Poke, Auto Like, Auto Share, Auto Sub Facebook..." />
<meta property="og:image" content="../images/banner.jpg" />
<meta property="og:locale" content="vi_VN" />

<!-- Bootstrap core CSS -->
<link href="../css/bootstrap.css" rel="stylesheet">
<link href="../css/docs.min.css" rel="stylesheet">
<link href="../css/main.css" rel="stylesheet">
<link rel="stylesheet" href="../css/smoke.css">
<link rel="stylesheet" href="../css/materialize.css">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="canonical" href="http://BOTLIKE.TOP/" />
<link rel="shortcut icon" href="../images/dm.png" />
<link rel="alternate" href="http://BOTLIKE.TOP/" hreflang="vi-vn" />

</head>
<body>
<style type="text/css"> 
HTML,BODY{cursor: url("../hub/c1.cur"), url("../hub/c1.cur"), auto;} 
A:hover,#submit{cursor: url("../hub/c2.cur"), url("../hub/c2.cur"), auto;} 
</style>

<script type="text/javascript" src="../js/jquery-1.8.1.js"></script>
<script src="../js/transition.js"></script>
<script src="../js/smoke.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/mainjs.js"></script>

<!-- Google Analytics -->
<?php include_once("analyticstracking.php") ?>

<!-- End Google Analytics -->

<!-- Apps Facebook -->
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1626028714353005',
      xfbml      : true,
      version    : 'v2.4'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.4&appId=1626028714353005";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!-- End Apps Facebook -->

<script type="application/ld+json">
{
 "@context":"http://schema.org",
 "@type":"WebSite",
 "url":"http://BOTLIKE.TOP/",
 "potentialAction":
 {
 "@type":"SearchAction",
 "target":"http://BOTLIKE.TOP/?s={search_term}",
 "query-input":"required name=search_term"
}
}
</script>

<!-- Fixed navbar -->
<div class="v4-tease"></div>
<nav class="navbar navbar-static-top bs-docs-nav">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">BOTLIKE.TOP</a>
</div>
<div id="navbar" class="navbar-collapse collapse">
<ul class="nav navbar-nav">
<li class="active">
<a href="index.php">
<span class="glyphicon glyphicon-home"></span>
</a>
</li>
<li>
									<a href="../help.html">
										<span class="glyphicon glyphicon-question-sign"></span>
										Hướng Dẫn
									</a>
</li>
<li ><a href="../about.html"><i class="fa fa-book fa-fw"></i> About us</a></li>			
<li ><a href="../policy.html"><i class="fa fa-gavel fa-fw"></i> Policy and Term</a></li>			
<li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Công Cụ Tiện Ích" aria-expanded="true"><i class="fa fa-wrench"></i> Công Cụ Tiện Ích <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li>
									<a data-target="#modal_get_user_info" id="get_user_info" data-toggle="modal">
										<span class="glyphicon glyphicon-random"></span>
										Kiểm Tra Thông Tin Người Dùng
									</a>
</li>		
<li>
									<a data-target="#modal_get_id_stt" id="get_id_stt" data-toggle="modal">
										<span class="glyphicon glyphicon-flag"></span>
										Lấy ID Status/Ảnh/Video
									</a>
								</li>
</ul>
                </li>
<li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Liên Hệ" aria-expanded="true"><i class="fa fa-facebook-official fa-fw"></i> Liên Hệ <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
<li><a href="https://www.facebook.com/106DH"><span class="glyphicon glyphicon-th-list"></span> Profile</a></li>
<li><a href="../contact.html"><span class="glyphicon glyphicon-envelope"></span> Email</a></li>
<li><a href="https://www.facebook.com/106DH"><i class="fa fa-user-plus"></i> Admin</a></li>
</ul>
                </li>			
<li><a href="../vip.html"><i class="fa fa-users"></i> VIP Membership</a></li>
</ul>
	<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
								<span class="glyphicon glyphicon-user"></span>
<? echo $_SESSION['name'] ?>								<span class="caret"></span>
							</a>
							<ul class="dropdown-menu" role="menu">
								<li>
									<a href="//fb.com/<? echo $_SESSION['id'] ?>" target="_blank">
										<img src="//graph.facebook.com/<? echo $_SESSION['id'] ?>/picture?width=24&amp;height=24">
										<? echo $_SESSION['name'] ?>
									</a>
								</li>
								<li>
									<a>
										<span class="glyphicon glyphicon-search"></span>
										ID: <b><? echo $_SESSION['id'] ?></b>
									</a>
								</li>
								<li>
									<a href="logout.php">
										<span class="glyphicon glyphicon-log-out"></span>
										&#272;&#259;ng xu&#7845;t
									</a>
								</li>
							</ul>
						</li>
					</ul>				</div>
			</div>
		</nav>
<!-- /Fixed navbar -->

<!-- Container -->
<br>
<div class="container" role="main">
<div class="row">
<div class="col-sm-12">
<script type="text/javascript"> 
function toSpans(span) { var str=span.firstChild.data; var a=str.length; span.removeChild(span.firstChild); for(var i=0; i<a; i++) { var theSpan=document.createElement("SPAN"); theSpan.appendChild(document.createTextNode(str.charAt(i))); span.appendChild(theSpan); }
}
function RainbowSpan(span, hue, deg, brt, spd, hspd) { this.deg=(deg==null?360:Math.abs(deg)); this.hue=(hue==null?0:Math.abs(hue)%360); this.hspd=(hspd==null?3:Math.abs(hspd)%360); this.length=span.firstChild.data.length; this.span=span; this.speed=(spd==null?50:Math.abs(spd)); this.hInc=this.deg/this.length; this.brt=(brt==null?255:Math.abs(brt)%256); this.timer=null; toSpans(span); this.moveRainbow();
}
RainbowSpan.prototype.moveRainbow = function() { if(this.hue>359) this.hue-=360; var color; var b=this.brt; var a=this.length; var h=this.hue; for(var i=0; i<a; i++) { if(h>359) h-=360; if(h<60) { color=Math.floor(((h)/60)*b); red=b;grn=color;blu=0; } else if(h<120) { color=Math.floor(((h-60)/60)*b); red=b-color;grn=b;blu=0; } else if(h<180) { color=Math.floor(((h-120)/60)*b); red=0;grn=b;blu=color; } else if(h<240) { color=Math.floor(((h-180)/60)*b); red=0;grn=b-color;blu=b; } else if(h<300) { color=Math.floor(((h-240)/60)*b); red=color;grn=0;blu=b; } else { color=Math.floor(((h-300)/60)*b); red=b;grn=0;blu=b-color; } h+=this.hInc; this.span.childNodes[i].style.color="rgb("+red+", "+grn+", "+blu+")"; } this.hue+=this.hspd;
}
</script>
<b><center><font face="tahoma" size="8" id="r3">WelCome To BOTLIKE.TOP</font></center></b>
<script type="text/javascript">var r3=document.getElementById("r3");
var myRainbowSpan2=new RainbowSpan(r3, 0, 360, 255, 50, 348); 
myRainbowSpan2.timer=window.setInterval("myRainbowSpan2.moveRainbow()", myRainbowSpan2.speed);
</script><center>