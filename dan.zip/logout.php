<?php
session_start();
session_destroy();
header('location: index.php?i=Good Bye. See You Again...!!!');
?>